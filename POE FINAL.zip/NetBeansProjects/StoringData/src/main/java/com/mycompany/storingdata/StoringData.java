/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.storingdata;

/**
 *
 * @author Kat
 */
import java.util.Scanner;

public class StoringData {

    // Parallel Arrays to store messages data
    private static String[] messageIDs = new String[10];
    private static String[] recipients = new String[10];
    private static String[] messages = new String[10];
    private static String[] flags = new String[10];
    private static String[] messageHashes = new String[10];
    private static int totalCount = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int menuSelection = 0;

        // Options that the user can choose from
        while (menuSelection < 5) {
            System.out.println("--MAIN MENU--");
            System.out.println("1. Add New Message Data");
            System.out.println("2. Display All Message Data");
            System.out.println("3. Run Automated Analysis");
            System.out.println("4. Stored Messages");
            System.out.println("5. Exit");
            System.out.println("Please enter your choice");
            menuSelection++;

            if (input.hasNextInt()) {
                menuSelection = input.nextInt();
                input.nextLine();

                switch (menuSelection) {
                    case 1:
                        addNewMessageData(input);
                        break;
                    case 2:
                        displayFullReport();
                        break;
                    case 3:
                        displayLongestMessage();
                        break;
                    case 4:
                        runStoredMessages(input);
                        break;
                    case 5:
                        System.out.println("Exiting application. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please select from the menu options.");

                }
            } else {
                System.out.println("Invalid input");
                input.nextLine();
            }
        }
        input.close();

    }

    private static void populateTestData() {
        // Message 1
        messageIDs[0] = "MSG001";
        recipients[0] = "+27834557896";
        messages[0] = "Did you get the cake?";
        flags[0] = "Sent";
        messageHashes[0] = "HASH111";

        // Message 2
        messageIDs[1] = "MSG002";
        recipients[1] = "+27838884567";
        messages[1] = "Where are you? You are late! I have asked you to be on time.";
        flags[1] = "Stored";
        messageHashes[1] = "HASH222";

        // Message 3
        messageIDs[2] = "MSG003";
        recipients[2] = "+27834484567";
        messages[2] = "Yohoooo, I am at your gate.";
        flags[2] = "Disregard";
        messageHashes[2] = "HASH333";

        // Message 4
        messageIDs[3] = "MSG004";
        recipients[3] = "0838884567";
        messages[3] = "It is dinner time!";
        flags[3] = "Sent";
        messageHashes[3] = "HASH444";

        // Message 5
        messageIDs[4] = "MSG005";
        recipients[4] = "+27838884567";
        messages[4] = "Ok, I am leaving without you.";
        flags[4] = "Stored";
        messageHashes[4] = "HASH555";

        totalCount = 5;

    }

    private static void addNewMessageData(Scanner input) {
        if (totalCount >= messageIDs.length) {
            System.out.println("Error: The array backend is completely full!");
            return;
        }
        System.out.print("Enter Message ID: ");
        messageIDs[totalCount] = input.nextLine();
        System.out.print("Enter Recipient Number: ");
        recipients[totalCount] = input.nextLine();
        System.out.print("Enter Message Body: ");
        messages[totalCount] = input.nextLine();
        System.out.print("Enter Status Flag(Sent/Stored/Disregard): ");
        flags[totalCount] = input.nextLine();
        System.out.print("Enter Unique Message Hash: ");
        messageHashes[totalCount] = input.nextLine();

        totalCount++;
        System.out.print("Message entry recorded successfully!");

    }

    private static void runStoredMessages(Scanner input) {
        System.out.print("---STORED MESSAGES SUB-MENU");
        System.out.print("A. Display sender and recipient of all stored messages");
        System.out.print("B. DIsplay longest stored message");
        System.out.print("C. Search for a message by ID");
        System.out.print("D. Search for all messages by recipient");
        System.out.print("E. Delete a message using hash");
        System.out.print("F. Display complete message report");
        System.out.print("Select sub-option (a-f): ");

        String option = input.nextLine();
        switch (option) {
            case "A":
                displaySendersAndRecipients();
                break;
            case "B":
                displayLongestMessage();
                break;
            case "C":
                System.out.print("Enter Message ID to locate: ");
                String searchID = input.nextLine();
                break;
            case "D":
                System.out.print("Enter Recipient phone number: ");
                String targetRecipient = input.nextLine();
                break;
            case "E":
                System.out.print("Enter Message Hash that you wanted to be deleted: ");
                String targetHash = input.nextLine();
                break;
            case "F":
                displayFullReport();
                break;
            default:
                System.out.println("Invalid option entered.");

        }
    }

    public static void displaySendersAndRecipients() {
        System.out.println("--STORED MESSAGES--");
        boolean foundAny = false;
        for (int i = 0; i < totalCount; i++) {
            if (flags[i].equalsIgnoreCase("Stored")) {
                System.out.print("Sender: System - Recipient: " + recipients[i]);
                foundAny = true;
            }
        }
        if (!foundAny) {
            System.out.println("No records found matching the 'Stored' flag status.");
        }
    }

    public static String displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < totalCount; i++) {
            if (messages[i] != null && messages[i].length() > longest.length()) {
                longest = messages[i];
            }
        }
        System.out.println("--LONGEST MESSAGE--");
        System.out.print("Longest Message text: \"" + longest + "\"");
        return longest;
    }

    public static String searchByMessageID(String searchID) {
        System.out.println("--TARGETED ID--");
        for (int i = 0; i < totalCount; i++) {
            if (messageIDs[i] != null && messageIDs[i].equalsIgnoreCase(searchID)) {
                System.out.println("Recipient: " + recipients[i]);
                System.out.println("Message Text: \"" + messages[i] + "\"");
                return messages[i];
            }
        }
        System.out.println("Message ID '" + searchID + "' was not found inside the system backend storage.");
        return null;
    }

    public static String searchAllByRecipient(String targetRecipient) {
        System.out.println("\n--- RECIPIENT INBOUND MESSAGE REPORT ---");
        StringBuilder results = new StringBuilder();
        for (int i = 0; i < totalCount; i++) {
            if (recipients[i] != null && recipients[i].equals(targetRecipient)) {
                System.out.println("- \"" + messages[i] + "\" [" + flags[i] + "]");
                results.append("\"").append(messages[i]).append("\" ");
            }
        }
        if (results.length() == 0) {
            System.out.println("No matching messages found for user: " + targetRecipient);
            return null;
        }
        return results.toString().trim();
    }

    public static boolean deleteMessageByHash(String targetHash) {
        for (int i = 0; i < totalCount; i++) {
            if (messageHashes[i] != null && messageHashes[i].equalsIgnoreCase(targetHash)) {
                String capturedMessageText = messages[i];

                for (int j = i; j < totalCount - 1; j++) {
                    messageIDs[j] = messageIDs[j + 1];
                    recipients[j] = recipients[j + 1];
                    messages[j] = messages[j + 1];
                    flags[j] = flags[j + 1];
                    messageHashes[j] = messageHashes[j + 1];
                }

                messageIDs[totalCount - 1] = null;
                recipients[totalCount - 1] = null;
                messages[totalCount - 1] = null;
                flags[totalCount - 1] = null;
                messageHashes[totalCount - 1] = null;

                totalCount--;
                System.out.println("Message: \"" + capturedMessageText + "\" successfully deleted.");
                return true;
            }
        }
        System.out.println("Delete action failed: Provided message hash code couldn't be resolved.");
        return false;
    }

    public static void readMockJsonFileIntoArray() {

        System.out.println(
                "Mock JSON stream systematically extracted, verified, and mapped back into data system arrays.");
    }

    public static void displayFullReport() {
        readMockJsonFileIntoArray(); // Attribution tracking call hook
        System.out.println("------");
        System.out.println("                SYSTEM MESSAGE REPORT                  ");
        System.out.println("------");
        for (int i = 0; i < totalCount; i++) {
            System.out.println("ID: " + messageIDs[i] + " | Hash: " + messageHashes[i]);
            System.out.println("Recipient Phone: " + recipients[i]);
            System.out.println("Status Category Flag: [" + flags[i] + "]");
            System.out.println("Message Content: " + messages[i]);
            System.out.println("------------------------");
        }
        System.out.println("TOTAL COUNT OF RECORDS REGISTERED: " + totalCount);
    }

    public static int getTotalCount() {
        return totalCount;
    }

    public static String[] getMessages() {
        return messages;
    }
}
