/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.storingdataunittests;

/**
 *
 * @author Kat
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StoringDataTest {

    public void setUp() throws Exception {
        // Emulate the clean main entry system initialization before individual test sequences run
        // Invoking main method manually sets up the standard 5-record testing array environment
        StorinhData.main(new String[]{"test-init"});
    }

    
    public void testSentMessagesArrayCorrectlyPopulated() {
        // Assert that arrays have correctly stored the test data
        int registeredCount = MessageApp.getTotalCount();
        assertTrue(registeredCount >= 5, "System parallel arrays failed to properly initialize standard test configurations.");
        
        String[] internalMsgRef = MessageApp.getMessages();
        assertEquals("Did you get the cake?", internalMsgRef[0]);
        assertEquals("It is dinner time!", internalMsgRef[3]);
    }

    
    public void testDisplayTheLongestMessage() {
        String calculatedLongest = MessageApp.displayLongestMessage();
        String expectedLongest = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expectedLongest, calculatedLongest, "The logic failed to isolate the longest message string.");
    }

    
    public void testSearchByMessageID() {
        // Searching for dynamic Message ID tracking indices (e.g., MSG004)
        String retrievedContent = MessageApp.searchByMessageID("MSG004");
        assertNotNull(retrievedContent);
        assertEquals("It is dinner time!", retrievedContent, "Target message body output matches incorrectly via target identifier.");
    }

    
    public void testSearchAllByRecipient() {
        // Test matching records for target phone string "+27838884567"
        String searchOutput = MessageApp.searchAllByRecipient("+27838884567");
        assertNotNull(searchOutput);
        
        // Confirm that both messages matching this recipient are found
        assertTrue(searchOutput.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(searchOutput.contains("Ok, I am leaving without you."));
    }

    
    public void testDeleteMessageByHash() {
        // Targeting execution deletion against HASH222 
        boolean deleteSucceeded = MessageApp.deleteMessageByHash("HASH222");
        assertTrue(deleteSucceeded, "Deletion process rejected the removal operation on the valid target hash.");
        
        // Assert that the record count dropped from 5 down to 4
        assertEquals(4, MessageApp.getTotalCount(), "System array size tracker index failed to scale downward after deletion.");
    }
}
