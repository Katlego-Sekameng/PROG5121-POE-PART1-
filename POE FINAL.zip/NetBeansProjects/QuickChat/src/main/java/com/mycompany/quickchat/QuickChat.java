/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchat;

import java.util.Scanner;

/**
 *
 * @author Kat
 */
public class QuickChat {
    
    //Declarations
    private static int messageCount = 0;
    //Methods
    public void createMessageHash(){
        System.out.println("Hash Created");
    }
    public void sentMessage(){
        System.out.println("Message sent");
    }
    public void storeMessage(){
        System.out.println("Message Stored");
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        QuickChat app = new QuickChat();
        
    String choice = " ";
    
    boolean running = false;

    while (running) {
        System.out.println("\n=== Welcome to QuickChat ===");
        System.out.println("1. Send Message");
        System.out.println("2. Store the Message so that you can send it later");
        System.out.println("3. Disregard the Message");
        System.out.println("Enter your choice (1-3): ");

        choice = input.nextLine();
        
        switch (choice){
            case "1":
                app.createMessageHash();
                break;
            case "2":
                app.sentMessage();
                break;
            case "3":
                app.storeMessage();
                break;
            case "4":
                running = false;
                System.out.println("Thank you for using QuickChat!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
 
        }
     
    }

}

public class StoringData {
    
    // Parallel Arrays to store messages data (Matching Part 3 requirements)
    private static String[] messageIDs = new String[10];
    private static String[] recipients = new String[10];
    private static String[] messages = new String[10];
    private static String[] flags = new String[10];
    private static String[] messageHashes = new String[10];
    private static int totalCount = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        populateTestData();
        
        boolean running = true;

        while (running) {
            System.out.println("-- MAIN MENU --");
            System.out.println("1. Add New Message Data");
            System.out.println("2. Display All Message Data");
            System.out.println("3. Run Automated Analysis (Longest Message)");
            System.out.println("4. Stored Messages Sub-Menu");
            System.out.println("5. Exit");
            System.out.print("Please enter your choice: ");

            String choice = input.nextLine();
            
            switch (choice) {
                case "1":
                    addNewMessageData(input);
                    break;
                case "2":
                    displayFullReport();
                    break;
                case "3":
                    displayLongestMessage();
                    break;
                case "4":
                    runStoredMessages(input);
                    break;
                case "5":
                    running = false;
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select from the menu options.");
            }
        }
        input.close();
    }

    private static void populateTestData() {
        
        messageIDs[0] = "MSG001";
        recipients[0] = "+27834557896";
        messages[0] = "Did you get the cake?"; 
        flags[0] = "Sent";
        messageHashes[0]="HASH111";
        
        messageIDs[1] = "MSG002";
        recipients[1] = "+27838884567";
        messages[1] = "Where are you? You are late! I have asked you to be on time.";
        flags[1] = "Stored"; 
        messageHashes[1]="HASH222";
        
        messageIDs[2] = "MSG003";
        recipients[2] = "+27834484567";
        messages[2] = "Yohoooo, I am at your gate."; 
        flags[2] = "Disregard";
        messageHashes[2] = "HASH333";
        
        messageIDs[3] = "MSG004"; 
        recipients[3] = "0838884567";
        messages[3] = "It is dinner time!";
        flags[3] = "Sent"; 
        messageHashes[3] = "HASH444";
        
        messageIDs[4] = "MSG005"; 
        recipients[4] = "+27838884567";
        messages[4] = "Ok, I am leaving without you."; 
        flags[4] = "Stored"; 
        messageHashes[4] = "HASH555";
        
        totalCount = 5;
    }

    private static void addNewMessageData(Scanner input) {
        if (totalCount >= messageIDs.length) {
            System.out.println("Error: Backend full!");
            return;
        }
        System.out.print("Enter Message ID: ");
        messageIDs[totalCount] = input.nextLine();
        System.out.print("Enter Recipient: ");
        recipients[totalCount] = input.nextLine();
        System.out.print("Enter Message Body: ");
        messages[totalCount] = input.nextLine();
        System.out.print("Enter Status Flag: ");
        flags[totalCount] = input.nextLine();
        System.out.print("Enter Hash: ");
        messageHashes[totalCount] = input.nextLine();
        totalCount++;
        System.out.println("Message recorded!");
    }

    private static void runStoredMessages(Scanner input) {
        System.out.println("\n--- STORED MESSAGES SUB-MENU ---");
        System.out.println("a. Display sender and recipient");
        System.out.println("b. Display longest message");
        System.out.println("c. Search by ID");
        System.out.println("d. Search by recipient");
        System.out.println("e. Delete by hash");
        System.out.println("f. Full report");
        System.out.print("Select (a-f): ");
        
        // FIX 3: Convert to upper case so 'a' and 'A' both work
        String option = input.nextLine().toUpperCase();
        switch (option) {
            case "A":
                displaySendersAndRecipients();
                break;
            case "B":
                displayLongestMessage();
                break;
            case "C":
                System.out.print("Enter ID: ");
                searchByMessageID(input.nextLine()); // Added method call
                break;
            case "D":
                System.out.print("Enter Recipient: ");
                searchAllByRecipient(input.nextLine()); // Added method call
                break;
            case "E":
                System.out.print("Enter Hash to Delete: ");
                deleteMessageByHash(input.nextLine()); // Added method call
                break;
            case "F":
                displayFullReport();
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    // Logic for finding the longest message
    public static String displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < totalCount; i++) {
            if (messages[i] != null && messages[i].length() > longest.length()) {
                longest = messages[i];
            }
        }
        System.out.println("\nLongest Message: " + longest);
        return longest;
    }

    public static void displaySendersAndRecipients() {
        for (int i = 0; i < totalCount; i++) {
            if (flags[i].equalsIgnoreCase("Stored")) {
                System.out.println("Sender: System -> Recipient: " + recipients[i]);
            }
        }
    }

    public static String searchByMessageID(String searchID) {
        for (int i = 0; i < totalCount; i++) {
            if (messageIDs[i] != null && messageIDs[i].equalsIgnoreCase(searchID)) {
                System.out.println("Found! Recipient: " + recipients[i] + " | Message: " + messages[i]);
                return messages[i];
            }
        }
        return null;
    }

    public static String searchAllByRecipient(String targetRecipient) {
        for (int i = 0; i < totalCount; i++) {
            if (recipients[i] != null && recipients[i].equals(targetRecipient)) {
                System.out.println("- " + messages[i]);
            }
        }
        return "";
    }

    public static boolean deleteMessageByHash(String targetHash) {
        for (int i = 0; i < totalCount; i++) {
            if (messageHashes[i] != null && messageHashes[i].equalsIgnoreCase(targetHash)) {
                // Shift elements to delete
                for (int j = i; j < totalCount - 1; j++) {
                    messageIDs[j] = messageIDs[j + 1];
                    recipients[j] = recipients[j+1];
                    messages[j] = messages[j+1];
                    flags[j] = flags[j+1];
                    messageHashes[j] = messageHashes[j+1];
                }
                totalCount--;
                System.out.println("Deleted successfully!");
                return true;
            }
        }
        return false;
    }

    public static void displayFullReport() {
        System.out.println("\n--- FULL REPORT ---");
        for (int i = 0; i < totalCount; i++) {
            System.out.println("ID: " + messageIDs[i] + " | Recipient: " + recipients[i] + " | Hash: " + messageHashes[i]);
        }
    }
    }
}


        
                    
                    