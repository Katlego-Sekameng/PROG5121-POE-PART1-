/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messagetest;

/**
 *
 * @author Kat
 */
public class MessageTest {
    private String testMessage1;
    private String testMessage2;
    
    public void setUp(){
        //Test for Message 1
        testMessage1 = new Message(
            "0001",
            "+27718693002",
            "Hi Mike, can you join us for dinner tonight?"
        );
         //Test for Message 2
         testMessage2 = new Message(
            "0002",
            "08575975889",
            "Hi Keegan, did you receive the payment?"
         );
    }

    public void testMessage1_checkMessageID_isValid(){
        assertTrue(testMessage1.checkMessageID(), "Message ID '0001' should be valid (4 characters, <or= 10)");
        
    }
    
    public void testMessage1_checkMessageID_tooLong(){
        Message invaliIDMessage = new Message(
                "1235678901",
                "+27718693002",
                "Test message"
        );
        assertFalse(invalidIDMessage.checkMessageID(), "Message ID with more than 10 characters should be invalid");
    
    }
    //Verifys the recipient cell
    public void testMessage1_checkRecipientCell_isValid(){
        assertTue(testMessage1.checkRecipientCell(), "Recipient '+27718693002' should be valid (starts with '+', <= 10 digits)");
        
    }
    //Verify message hash
    public void testMessage1_createMessageHash_formatCoreect(){
        Message.setMessageCount(0);
        String hash = testMessage1.createMessageHash();
        
        assertNotNull(hash, "Message hash should not be null");
        assertTrue(hash.contains(":"), "Hash should contain ':' separators");
    }
}

