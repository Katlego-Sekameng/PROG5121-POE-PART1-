/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.message;

/**
 *
 * @author Kat
 */

public class Message {
    private String messageID;
    private String recipientCell;
    private String messageHash;

}

public Message (String messageID, String recipientCell, String message) {
    this.messageID = messageID;
    this.recipientCell = receipientcell;
    this.message = message;
    this.messageHash = messageHash;
}
//Checking the Id of the message
public boolean checkMessageID() {
    if (messageID == null) {
        return false;
    }
   
}
//Checking the cell number of the recipient
public boolean checkRecipientCell() {
    if (receipientCell == null) {
        return false;
    }
    else{
        return recipientCell.length() <= Maximum cellNumber length
    }
//Checks whether does the receipient cell starts with an international code or not
    if (recipientCell.starts with ("+")) {
        return true;
    }
}

public String createMessageHash() {
    String idPrefix = messageId.length() >= 2
          messageID.substring(0, 2):
          String.format("%02d", Interger(messsageID));
          
          //Get message count
          String countStr = String.valueOf(messageCout);
          
          //Extracting first and last words from message
          String[] words = message.trim().split("\\s+");
          String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "").toUpperCase();
          
          //Create hash 
          this.messageHash = idPrefix + ":" + countStr + ":" + firstWord + lastWord;
          return this.messageHash;
}



//This allows the user to choose between sending, storing or disregarding the message
public String SentMessage(){
    Scanner input = new Scanner(System.in);
    String choice = " ";
    boolean validChoice = false;

    while (!validChoice) {
        System.out.println("Message Options");
        System.out.println("1. Send Message");
        System.out.println("2. Store the Message so that you can send it later");
        System.out.println("3. Disregard the Message");
        System.out.println("Enter your choice (1-3): ");

        choice = input.nextLine();

        switch (choice) {
            case "1":
                messageCount++;
                createMessageHash();
                sentMessage;
                System.out.println("Message successfully sent");
                validChoice = true;
                break;
                case "2":
                    System.out.println("Press 0 to delete the message");
                    if (equals("0")){
                        System.out.println("Disregard Message");
                    }
                    break;
                    case "3":
                        createMessageHash();
                        storeMessage();
                        System.out.println("Message successfully stored");
                        validChoice = true;
                        break;
                        default:
                            System.out.println("Invalid choice. Please enter these options (1, 2 or 3");
        }
    }
    return choice;


}
public String printMessages(){
    if (sent.Messsage.isEmpty()){
        return "No messages sent";
    }

    for (Message msg : sentMessages) {
        output.append("Message ID: ");
        output.append("Message Hash: ");
        output.append("Recipient: ");
        output.append("Message: ");
        
    }
    return output.toString();
}

//Returns the number of messages sent
public int returnTotalMessages(){
    return messageCount;
}

//Stores the message to a JSON file
public void storeMessage(){
    try{
        //This helps to read messages that are already stored 
        JSONArray messagesArray = new JSONArray();

        //Create JSON object for this message
        JSONObject messageObj = new JSONObject();
        messageObj.put("messageID", this.messageID);
        messageObj.put("messageHash", this.messageHash);
        messageObj.put("recipient cell", this.recipientCell);
        messageObj.put("message", this.message);
    }
}

