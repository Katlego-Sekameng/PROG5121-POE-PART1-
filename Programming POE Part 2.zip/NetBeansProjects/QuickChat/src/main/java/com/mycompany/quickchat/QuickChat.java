/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchat;

import java.util.Scanner;

/**
 *
 * @author Kat
 */
public class QuickChat {
    //Declarations
    private static int messageCount = 0;
    //Methods
    public void createMessageHash(){
        System.out.println("Hash Created");
    }
    public void sentMessage(){
        System.out.println("Message sent");
    }
    public void storeMessage(){
        System.out.println("Message Stored");
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        QuickChat app = new QuickChat();
        
    String choice = " ";
    
    boolean running = false;

    while (running) {
        System.out.println("\n=== Welcome to QuickChat ===");
        System.out.println("1. Send Message");
        System.out.println("2. Store the Message so that you can send it later");
        System.out.println("3. Disregard the Message");
        System.out.println("Enter your choice (1-3): ");

        choice = input.nextLine();
        
        switch (choice){
            case "1":
                app.createMessageHash();
                break;
            case "2":
                app.sentMessage();
                break;
            case "3":
                app.storeMessage();
                break;
            case "4":
                running = false;
                System.out.println("Thank you for using QuickChat!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                
           

        
                    
                    }
        }
        input.close();

    }
}
