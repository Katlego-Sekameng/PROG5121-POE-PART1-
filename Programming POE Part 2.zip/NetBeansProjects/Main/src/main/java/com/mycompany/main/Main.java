/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author Kat
 */

import java.util.Scanner;

public class Main {
    //QuickChat class definitions
    static class QuickChat {
        //Declarations
        private static int messageCount = 0;
        
        //Methods
        public void createMessageHash(){
        System.out.println("Hash Created");
    }
    public void sentMessage(){
        System.out.println("Message sent");
    }
    public void storeMessage(){
        System.out.println("Message Stored");
    
    }
    public void disregardMessage(){
        System.out.println("Disregard the message");
    }
}

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Registration

        System.out.println("REGISTRATION");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        String username;
        System.out.print("Enter username (must contain '_' and be <= 5 chars): ");
        String user = input.nextLine();

        String Password;
        System.out.print("Enter password (>=8 chars,1 uppercase,1 number,1 special char): ");
        String password = input.nextLine();

        String phoneNumber;
        System.out.print("Enter Phone(+27....): ");
        String phonenumber = input.nextLine();

        // Login (Only if you registered successfully)
        System.out.println("Login ");
        
        //Declarations
        
        String pass = " ";
        
        boolean loggedIn = false;
        if (!loggedIn){
            System.out.print("Enter username: ");
            String loginUser = input.nextLine();
            
            System.out.print("Enter password: ");
            String loginPass = input.nextLine();
            
            if(loginUser.equals(user) && loginPass.equals(pass)) {
                System.out.println("Login successful!");
                loggedIn = true;
            
        
        }
        
        QuickChat app = new QuickChat();
        
    String choice = " ";
    
    boolean running = false;

    while (!running) {
        System.out.println("\n=== Welcome to QuickChat ===");
        System.out.println("1. Send Message");
        System.out.println("2. Store the Message so that you can send it later");
        System.out.println("3. Disregard the Message");
        System.out.print("Enter your choice (1-3): ");

        choice = input.nextLine();
        
        switch (choice){
            case "1":
                app.sentMessage();
                break;
            case "2":
                app.storeMessage();
                break;
            case "3":
                app.disregardMessage();
                break;
            case "4":
                running = false;
                System.out.println("Thank you for using QuickChat!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
           }
       }
        
   

    }
        
        
    }
}
