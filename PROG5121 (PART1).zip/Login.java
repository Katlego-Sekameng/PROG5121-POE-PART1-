/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/**
 *
 * @author Kat
 */

package com.mycompany.login;
import com.mycompany.registration.Registration;

public class Login {
    
    private Registration registeredUser;
    
    //Constructor
    public Login(Registration registeredUser){
        this.registeredUser = registeredUser; 
    }
    
    //Verifies that the details used to login matches that of the registered user
    public boolean loginUser(String enteredUsername, String enteredPassword){
        return registeredUser.getUsername().equals(enteredUsername)
                && registeredUser.getPassword().equals(enteredPassword);
    }
    
    //Returning a login message after loging
    
    public String returnLoginStatus(String enteredUsername, String enteredPassword){
        if (loginUser(enteredUsername, enteredPassword)){
            return("Welcome " +registeredUser.getFirstName() +" " +registeredUser.getLastName() +"It is great to see you again");
        }else{
           return("The username or password that you entered is incorrect, please try again");
        }
        
    }
     
}
