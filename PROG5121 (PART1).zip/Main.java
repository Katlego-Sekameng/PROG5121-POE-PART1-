/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author Kat
 */
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        
     Scanner input = new Scanner(System.in);
     
     //Registration
     
     System.out.println("REGISTRATION");
     
     System.out.print("Enter your first name: ");
     String firstName = input.nextLine();
     
     System.out.print("Enter your last name: ");
     String lastNmae = input.nextLine();
     
     
     String username;
     System.out.print("Enter username (must contain '_' and be <= 5 chars): ");
     String user = input.nextLine();
     
     String Password;
     System.out.print("Enter password (>=8 chars,1 uppercase,1 number,1 special char): ");
     String password = input.nextLine();
     
     String phoneNumber;
     System.out.print("Enter Phone(+27....): ");
     String phonenumber = input.nextLine();
  
     
     //Login (Only if you registered successfully)
     if (user.contains("successfully captured")){
     System.out.println("Login");
     System.out.println(" Enter username: ");
     String loginUser = input.nextLine();
     
     System.out.println("Password: ");
     String loginPass = input.nextLine();
     
     }
     
     input.close();
     
    }
}
