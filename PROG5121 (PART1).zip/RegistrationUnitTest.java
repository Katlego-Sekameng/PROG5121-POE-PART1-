/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationunittest;


import com.mycompany.registration.Registration;
import org.junit.jupiter.api.Test;


public class RegistrationUnitTest {
    
    
    void usernameTests(){
        Registration reg1 = new Registration("username","password", "+27636579824", "Katlego", "Sekameng");
        assertEquals(true, reg1.checkUsername());//<=5 + "_"
        
        Registration reg2 = new Registration("long name","password","+27636579824","Katlego","Sekameng");
        assertEquals(false, reg2.checkUsername());//>=5 and there is underscore 
    }
    
    void passwordTests(){
        Registration reg1 = new Registration("username","password","+27636579824","Katlego","Sekameng");
        assertTrue(reg1.checkPasswordComplexity());//meets the requirements
        
        Registration reg2 = new Registration("username","password","=27636579824","Katlego","Sekameng");
        assertFalse(reg2.checkPasswordComplexity());//doesn't meet the requirements
    }
}
