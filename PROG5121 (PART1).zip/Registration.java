/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;

/**
 *
 * @author Kat
 */

public class Registration {
    
    
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;
    
    //Constructor
    public Registration(String firstName, String lastName, String username, String password, String cellPhoneNumber){
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }
    
    public boolean checkUsername(String username){
        if (username.contains("_") && username.length() <= 5){
            this.username = username;
            System.out.println("Username is successfully Captured");
            return true;
        } else{
            System.out.println("Username is not correctly formatted as required; please ensure that your username contains an underscore and is no more than five characters in length");
            return false;
        }
    }
    
    // Checking the Complexity of the password
    public boolean checkPasswordComplexity(String password){
        String regex = "^(?=.*[!@#$%^&*=])(?=.*[A-Z])(?=.*\\d).{8,}$";
        if (password.matches(regex)){
            this.password = password;
            System.out.println("Password successfully captured");
            return true;
        }else{
            System.out.println("Passowrd is not successfully formatted as required; please ensure that the password contains at least eight characters,a uppercase letter and a special character.");
            return false;
        }
    }
    
    //Checking whether does the cellphone number is a South African registered number,it should have a international code
    //It must start with +27 followed by 10 digits
    public boolean checkCellPhoneNumber(String phonenumber){
        String regex = "^\\+\\d{2}\\d{10}$";
        if (cellPhoneNumber.matches(regex)){
            this.cellPhoneNumber = cellPhoneNumber;
            System.out.println("Cellphone number is successfully added");
            return true;
        }else{
            System.out.println("Cellphone Number is incorrectly formatted");
            return false;
        }
    }
}
    
    
    
    



    


