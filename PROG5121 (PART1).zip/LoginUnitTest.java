/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginunittest;
import org.junit.junit.jupiter.api.Test;

/**
 *
 * @author Kat
 */
public class LoginUnitTest {

    void loginTests(){
        Registration reg = new Registration("username","password","+27636579824","Katlego","Sekameng");
        Login login = Login(reg);
        
        //If the user has logged in correctly
        assertTrue(login.loginUser("username","Password"));
        assertEquals("Welcome Katlego Sekameng,it is great to see you again", login.returnLoginStatus("username","Password"));
        
        //If the user didn't login correctly
        assertFalse(login.loginUser("username","password"));
        assertEquals("Welcome Katlego Sekameng,it is great to see you again", login.returnLoginStatus("username","Password"));
    }
}
